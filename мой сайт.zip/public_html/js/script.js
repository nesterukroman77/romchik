function checkPincode() {
	var pincode = document.getElementById('pincode').value;
	if (pincode == '2305') {
		document.getElementById('file').style.display = 'block';
	} else {
		document.getElementById('file').style.display = 'none';
	}
}