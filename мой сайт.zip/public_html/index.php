﻿<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>romchik</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	
      <meta name="description" content="Официальный сайт romchik">
      <meta name="keywords" content="гта россия, crmp android, гта андроид, BLACK RUSSIA скачать, крмп на телефон, купить форум крмп мобайл, заказать крмп мобайл, купить crmp mobile проект, заказать crmp mobile проект">
      <link rel="icon" href="img/favicon.ico">

    <link rel="stylesheet" href="css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css%20%281%29/bootstrap.min.css">
    <link rel="stylesheet" href="css%20%281%29/magnific-popup.css">
    <link rel="stylesheet" href="css%20%281%29/jquery-ui.css">
    <link rel="stylesheet" href="css%20%281%29/owl.carousel.min.css">
    <link rel="stylesheet" href="css%20%281%29/owl.theme.default.min.css">


    <link rel="stylesheet" href="css%20%281%29/aos.css">

    <link rel="stylesheet" href="css%20%281%29/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">
    <header class="site-navbar" role="banner">
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">
          	
   <div class="col-6 col-md-4 order-2 order-md-1 site-search-icon text-left">
           
                <input type="text" class="form-control border-0" placeholder="CRMP mobile">
              </form>
            </div>
            
            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-center">
              <div class="site-logo">
                <a href="index.php" class="js-logo-clone">romchik</a>
              </div>
            </div>

          </div>
        </div>
      </div> 

 </header>

    <div class="site-blocks-cover" style="background-image: url(images/hero_1.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-start align-items-md-center justify-content-end">
          <div class="col-md-5 text-center text-md-left pt-5 pt-md-0">
            <h1 class="mb-2">Закажи собственный форум и сайт </h1>
            <div class="intro-text text-center text-md-left">
              <p class="mb-4">Магазин для покупки форума и сайта на заказ!</p>
              <p>
                <a href="#foto" class="btn btn-sm btn-primary">Подробнее</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section site-section-sm site-blocks-1">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="">
            <div class="icon mr-4 align-self-start">
              <span class="icon-truck"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">КАЧЕСТВЕННО</h2>
              <p></p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="100">
            <div class="icon mr-4 align-self-start">
              <span class="icon-refresh2"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">ЧЕСТНО</h2>
              <p>Имеются отзывы</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 d-lg-flex mb-4 mb-lg-0 pl-4" data-aos="fade-up" data-aos-delay="200">
            <div class="icon mr-4 align-self-start">
              <span class="icon-help"></span>
            </div>
            <div class="text">
              <h2 class="text-uppercase">БЕЗОПАСНО</h2>
              <p>Оплата после просмотра заказа</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section block-3 site-blocks-2 bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 site-section-heading text-center pt-4">
          <img id="foto">
            <h2>Что можно приобрести</h2>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">
            <div class="nonloop-block-3 owl-carousel">

              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/brforum.png" alt="BLACK RUSSIA FORUM.png" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                  <h2><a href="#">BLACK RUSSIA FORUM</a></h2>
                    <h3><a href="#"> </a></h3>
                    <a href="brforum.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">50₽</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">
            <div class="nonloop-block-3 owl-carousel">

              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/brwebsite.png" alt="BLACK RUSSIA WEBSITE.png" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                  <h2><a href="#">BLACK RUSSIA WEBSITE</a></h2>
                    <h3><a href="#"> </a></h3>
                    <a href="brwebsite.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">70₽</p>
                  </div>
                </div>
              </div>

          </div>
          </div>
        </div>


              <div class="row">
          <div class="col-md-12">
            <div class="nonloop-block-3 owl-carousel">

              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/matrforum.png" alt="Матрёшка РП FORUM.png" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                  <h2><a href="#">Матрешка РП FORUM</a></h2>
                    <h3><a href="#"> </a></h3>
                    <a href="matrforum.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">90₽</p>
                  </div>
                </div>
              </div>
             
            </div>
          </div>
        </div>


      </div>
    </div>
<div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/snow.png" alt="Снег на сайт.png" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                  <h2><a href="#">Установка снега на сайт</a></h2>
                    <h3><a href="#"> </a></h3>
                    <a href="snow.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">10₽</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            romchik™ © 2024
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>
    
  

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>