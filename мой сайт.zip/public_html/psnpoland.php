<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Автоматическое перенаправление</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
        button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <h1>Автоматическое перенаправление</h1>
    <p>Этот сайт автоматически перенаправит вас на другую страницу через 5 секунд.</p>
    <button onclick="redirect()">Перенаправить</button>

    <script>
        function redirect() {
            setTimeout(function() {
                window.location.href = "index.php";
            }, 5000);
        }
    </script>
</body>
</html>