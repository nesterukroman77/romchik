﻿<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>romchik</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<ul id="navbar">

    <link rel="stylesheet" href="css?family=Mukta:300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css%20%281%29/bootstrap.min.css">
    <link rel="stylesheet" href="css%20%281%29/magnific-popup.css">
    <link rel="stylesheet" href="css%20%281%29/jquery-ui.css">
    <link rel="stylesheet" href="css%20%281%29/owl.carousel.min.css">
    <link rel="stylesheet" href="css%20%281%29/owl.theme.default.min.css">


    <link rel="stylesheet" href="css%20%281%29/aos.css">

    <link rel="stylesheet" href="css%20%281%29/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">
    <header class="site-navbar" role="banner">
      <div class="site-navbar-top">
        <div class="container">
          <div class="row align-items-center">
<ul>
             </form>
            </div>

            <div class="col-12 mb-3 mb-md-0 col-md-4 order-1 order-md-2 text-center">
              <div class="site-logo">
                <a href="index.php" class="js-logo-clone">romchik</a>
              </div>
            </div>
            </div></div></div></header>

    <div class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0"><a href="index.php">Главная</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Режим работы</strong></div>
        </div>
      </div>
    </div>  

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <img src="images/rezhim-raboty.png" alt="Режим работы.png" class="img-fluid">
          </div>
          <div class="col-md-6">
           <h2 class="text-black">Режим работы</h2>
            <h2 class="text-black">Новый график</h2>

<p class="mb-4"></p>
            <p><strong class="text-primary h4">Пн-Пт 09:00-22:00
Сб-Вс 10:00-21:30</strong></p>
            <p><a href="https://t.me/nesterukroman77" class="buy-now btn btn-sm btn-primary">Мой лс</a></p>

          </div>
        </div>
      </div>
    </div>

    <div class="site-section block-3 site-blocks-2 bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>Другое</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="nonloop-block-3 owl-carousel">

              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/brforum.png" alt="Image placeholder" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="">BLACK RUSSIA FORUM</a></h3>
                    <a href="brforum.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">50₽</p>
                  </div>
                </div>
              </div>
          
              <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/brwebsite.png" alt="BLACK RUSSIA WEBSITE" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="">BLACK RUSSIA WEBSITE</a></h3>
                    <a href="brwebsite.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">70₽</p>
                  </div>
                </div>
              </div>



          <div class="item">
                <div class="block-4 text-center">
                  <figure class="block-4-image">
                    <img src="images/snow.png" alt="Снег на сайт.png" class="img-fluid">
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a href="">Установка снега на сайт</a></h3>
                    <a href="snow.php" class="btn btn-sm btn-primary">ПОДРОБНЕЕ</a>
                    <p class="text-primary font-weight-bold">10₽</p>
                  </div>
                </div>
              </div>
              </div>
        </div>
      </div>
    </div>

        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          romchik™ © 2024
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>